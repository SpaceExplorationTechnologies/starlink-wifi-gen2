
Autoconf Archive fetched from:

http://gnu.mirror.iweb.com/autoconf-archive/autoconf-archive-2015.09.25.tar.xz

Grabbed the minimum files needed for the AX_APPEND_COMPILE_FLAGS and
AX_COMPILE_CHECK_SIZEOF macros.

