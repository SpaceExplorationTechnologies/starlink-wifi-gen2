#define __NR_io_setup           268
#define __NR_io_destroy         269
#define __NR_io_submit          270
#define __NR_io_cancel          271
#define __NR_io_getevents       272
