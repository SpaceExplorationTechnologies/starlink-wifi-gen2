/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * MediaTek Inc. (C) 2010. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <unistd.h>
#include <sys/ioctl.h>

//#include "bt_nvram.h"
#include "CFG_BT_Default.h"
#include "bt_drv.h"
#include "os_dep.h"
#include "bt_kal.h"


/* For BT_HOT_OP_SET_FWASSERT */
#define COMBO_IOC_MAGIC              0xb0
#define COMBO_IOCTL_FW_ASSERT        _IOWR(COMBO_IOC_MAGIC, 0, void*)

/* For BT_AUDIO_OP_GET_CONFIG */
struct audio_t {
  int chip_id;
  AUDIO_CONFIG audio_conf;
};

/**************************************************************************
 *                  G L O B A L   V A R I A B L E S                       *
***************************************************************************/
#if 0

// mtk bt library
static void *glib_handle = NULL;
typedef int (*INIT)(void);
typedef int (*UNINIT)(int fd);
typedef int (*WRITE)(int fd, unsigned char *buffer, unsigned long len);
typedef int (*READ)(int fd, unsigned char *buffer, unsigned long len);
typedef int (*NVRAM)(unsigned char *ucNvRamData);
typedef int (*GETID)(unsigned long *pChipId);

INIT    mtk = NULL;
UNINIT  bt_restore = NULL;
WRITE   write_com_port = NULL;
READ    read_com_port = NULL;
NVRAM   bt_read_nvram = NULL;
GETID   bt_get_combo_id = NULL;

#else

extern int mtk(void);
extern int bt_restore(int fd);
extern int write_com_port(int fd, unsigned char *buffer, unsigned long len);
extern int read_com_port(int fd, unsigned char *buffer, unsigned long len);
extern int bt_send_data(int fd, unsigned char *buffer, unsigned long len);
extern int bt_receive_data(int fd, unsigned char *buffer, unsigned long len);
extern int bt_get_combo_id(unsigned long *pChipId);
extern int bt_read_nvram(ap_nvram_btradio_struct *ucNvRamData);
extern
BOOL BT_InitDevice(
    HANDLE  hComPortFile,
    PBYTE   ucNvRamData,
    DWORD   dwBaud,
    DWORD   dwHostBaud,
    DWORD   dwFlowControl,
    SETUP_UART_PARAM_T setup_uart_param
);

#endif

/* Audio interface & Codec information Mapping */
struct audio_t audio_conf_map[] = {
    { 0x6620,    { PCM,              SYNC_8K,  SHORT_FRAME,  0 } },

#if defined(MTK_MERGE_INTERFACE_SUPPORT)
    { 0x6628,    { MERGE_INTERFACE,  SYNC_8K,  SHORT_FRAME,  0 } },
#else
    { 0x6628,    { PCM,              SYNC_8K,  SHORT_FRAME,  0 } },
#endif

    { 0x6572,    { CVSD_REMOVAL,     SYNC_8K,  SHORT_FRAME,  0 } },

    { 0x6582,    { CVSD_REMOVAL,     SYNC_8K,  SHORT_FRAME,  0 } },

    { 0x6592,    { CVSD_REMOVAL,     SYNC_8K,  SHORT_FRAME,  0 } },

    { 0x6752,    { CVSD_REMOVAL,     SYNC_8K,  SHORT_FRAME,  0 } },

    { 0x6735,    { CVSD_REMOVAL,     SYNC_8K,  SHORT_FRAME,  0 } },
    { 0x0321,    { CVSD_REMOVAL,     SYNC_8K,  SHORT_FRAME,  0 } },
    { 0x0335,    { CVSD_REMOVAL,     SYNC_8K,  SHORT_FRAME,  0 } },
    { 0x0337,    { CVSD_REMOVAL,     SYNC_8K,  SHORT_FRAME,  0 } },

#if defined(MTK_MERGE_INTERFACE_SUPPORT)
    { 0x6630,    { MERGE_INTERFACE,  SYNC_8K,  SHORT_FRAME,  0 } },
#else
    { 0x6630,    { PCM,              SYNC_8K,  SHORT_FRAME,  0 } },
#endif
    { 0x8127,    { CVSD_REMOVAL,     SYNC_8K,  SHORT_FRAME,  0 } },

	{ 0x6625,	 { CVSD_REMOVAL,	 SYNC_8K,  SHORT_FRAME,  0 } },

    { 0,         { 0 } }
};

/**************************************************************************
 *                          F U N C T I O N S                             *
***************************************************************************/

static void wait_whole_chip_reset_complete(int bt_fd)
{
    UCHAR temp;
    int   res;

    do {
        res = read(bt_fd, &temp, 1);
        if (res < 0){
            if (errno == 88)
                usleep(200000);
            else if (errno == 99)
                break;
            else if (errno != EINTR && errno != EAGAIN)
                break;
        }
        else{
            break; // impossible case
        }
    } while(1);
}

int mtk_bt_enable(int flag, void *func_cb)
{
    int bt_fd = -1;

    LOG_TRC();

    bt_fd = mtk();
    if (bt_fd < 0)
        goto error;

    LOG_DBG("BT is enabled success\n");

    return bt_fd;

error:
    return -1;
}

int mtk_bt_disable(int bt_fd)
{
    LOG_TRC();

    if (bt_fd <= 0){
        LOG_ERR("mtk bt library is unloaded!\n");
        return -1;
    }

    bt_restore(bt_fd);
    return 0;
}

int mtk_bt_write(int bt_fd, unsigned char *buffer, unsigned long len)
{
    int ret_val;

    LOG_DBG("bt_fd %d, buffer %x, len %ld\n", bt_fd, (int)buffer, len);

    ret_val = write_com_port(bt_fd, buffer, len);

    if (ret_val < 0 && (ret_val == -88)){
        // whole chip reset, wait it complete (errno 99)
        wait_whole_chip_reset_complete(bt_fd);
        ret_val = -99;
    }

    return ret_val;
}

int mtk_bt_read(int bt_fd, unsigned char *buffer, unsigned long len)
{
    int ret_val;

//    LOG_DBG("bt_fd %d, buffer %x, len %d\n", bt_fd, buffer, len);

    ret_val = read_com_port(bt_fd, buffer, len);

    if (ret_val < 0 && (ret_val == -88)){
        // whole chip reset, wait it complete (errno 99)
        wait_whole_chip_reset_complete(bt_fd);
        ret_val = -99;
    }

    if (ret_val > 0)
    	LOG_DBG("bt_fd %d, buffer %x, len %ld, read %d\n", bt_fd, (int)buffer, len, ret_val);

    return ret_val;
}

void mtk_bt_op(BT_REQ req, BT_RESULT *result)
{
    result->status = FALSE;

    switch(req.op)
    {
      case BT_COLD_OP_GET_ADDR:
      {
        unsigned char nvram[sizeof(ap_nvram_btradio_struct)];
        unsigned char ucDefaultAddr[6] = {0};
        unsigned long chipId;

        LOG_DBG("BT_COLD_OP_GET_ADDR\n");

        if(bt_read_nvram((ap_nvram_btradio_struct *)nvram) < 0){
            LOG_ERR("Read Nvram data fails\n");
            return;
        }

        /* Get combo chip id */
        if(bt_get_combo_id(&chipId) < 0){
            LOG_ERR("Get combo chip id fails\n");
            return;
        }

        switch(chipId)
        {
#ifndef MTK_MT7622
          case 0x6620:
            memcpy(ucDefaultAddr, stBtDefault_6620.addr, 6);
            break;
          case 0x6628:
            memcpy(ucDefaultAddr, stBtDefault_6628.addr, 6);
            break;
          case 0x6572:
            memcpy(ucDefaultAddr, stBtDefault_6572.addr, 6);
            break;
          case 0x6582:
            memcpy(ucDefaultAddr, stBtDefault_6582.addr, 6);
            break;
          case 0x6592:
            memcpy(ucDefaultAddr, stBtDefault_6592.addr, 6);
            break;
          case 0x6752:
            memcpy(ucDefaultAddr, stBtDefault_6752.addr, 6);
            break;
          case 0x6735:
		  case 0x0321:
			memcpy(ucDefaultAddr, stBtDefault_6735_0321.addr, 6);
			break;
		  case 0x0335:
			memcpy(ucDefaultAddr, stBtDefault_6735_0335.addr, 6);
			break;
	      case 0x0337:
            memcpy(ucDefaultAddr, stBtDefault_6735_0337.addr, 6);
            break;
          case 0x6630:
            memcpy(ucDefaultAddr, stBtDefault_6630.addr, 6);
            break;
          case 0x8127:
            memcpy(ucDefaultAddr, stBtDefault_8127.addr, 6);
            break;
          case 0x6625:
            memcpy(ucDefaultAddr, stBtDefault_6625.addr, 6);
            break;
#endif
          default:
            LOG_ERR("Unknown combo chip id\n");
            return;
        }

        result->status = TRUE;
        if (0 == memcmp(nvram, ucDefaultAddr, 6))
        {
            LOG_DBG("Nvram BD address default value\n");
            result->param.addr[0] = 0;  //default address
            memcpy(&result->param.addr[1], nvram, 6);
        }
        else {
            LOG_DBG("Nvram BD address has valid value\n");
            result->param.addr[0] = 1;  //valid address
            memcpy(&result->param.addr[1], nvram, 6);
        }
        break;
      }
      case BT_HOT_OP_SET_FWASSERT:
      {
        LOG_DBG("BT_HOT_OP_SET_FWASSERT\n");

        // req.param.assert.fd should be the fd returned by mtk_bt_enable
        if (req.param.assert.fd < 0){
            LOG_ERR("Invalid bt fd!\n");
            return;
        }

        if (ioctl(req.param.assert.fd, COMBO_IOCTL_FW_ASSERT, \
            req.param.assert.reason) < 0){
            LOG_ERR("Set COMBO FW ASSERT fails\n");
            return;
        }

        result->status = TRUE;
        break;
      }
      case BT_AUDIO_OP_GET_CONFIG:
      {
        unsigned long chipId;
        int i;

        LOG_DBG("BT_AUDIO_OP_GET_CONFIG\n");

        /* Get combo chip id */
        if(bt_get_combo_id(&chipId) < 0){
            LOG_ERR("Get combo chip id fails\n");
            return;
        }

        /* Return the specific audio config on current chip */
        for(i = 0; audio_conf_map[i].chip_id; i++){
            if(audio_conf_map[i].chip_id == chipId){
                memcpy(&result->param.audio_conf, &audio_conf_map[i].audio_conf,
                    sizeof(AUDIO_CONFIG));
                result->status = TRUE;
                return;
            }
        }

        result->status = FALSE;
        break;
      }
      case BT_DRV_OP_FW_CFG:
      {
#ifdef MTK_MT7622
        unsigned char nvram[sizeof(ap_nvram_btradio_struct)];
        int fd = req.param.fd;
        int speed = 0, iUseFlowControl =0;
        SETUP_UART_PARAM_T uart_setup_callback = NULL;

        LOG_DBG("BT_DRV_OP_FW_CFG\n");

        if(bt_read_nvram((ap_nvram_btradio_struct *)nvram) < 0){
            LOG_ERR("Read Nvram data fails\n");
            return;
        }
        BT_InitDevice(fd, nvram, speed, speed, iUseFlowControl, uart_setup_callback);
        result->status = TRUE;
#endif
        break;
      }
      default:
        LOG_DBG("Unknown operation %d\n", req.op);
        break;
    }

    return;
}
